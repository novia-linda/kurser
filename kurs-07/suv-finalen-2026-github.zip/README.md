# SUV-finalen 2026

Statisk HTML/CSS/JS-sajt för GitHub Pages.

## Publicera på GitHub Pages
1. Skapa ett nytt repository på GitHub.
2. Packa upp ZIP-filen och ladda upp allt innehåll i repositoryts rot.
3. Gå till **Settings → Pages**.
4. Välj **Deploy from a branch** och `main` / root.
5. GitHub visar sedan webbadressen till sajten.

Ingen byggprocess, Node eller externa bibliotek behövs.

## Sidor
- `index.html` – översikt
- `jamforelse.html` – stora jämförelsen
- `match.html` – interaktiv viktning
- `kostnad.html` – interaktiv 6-årskalkyl
- `provkorning.html` – provkörningsplan
- `sources.html` – källor

Senast faktakollad: 2026-08-15.
