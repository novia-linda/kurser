window.CARS={
  "ev6": {
    "name": "Kia EV6 GT-Line AWD",
    "short": "EV6",
    "price": 57135.5,
    "strength": "Modern 800 V-teknik, lång garanti och lokal Kia-service i Vasa.",
    "scores": {
      "tech": 8.7,
      "software": 8.4,
      "charging": 9.5,
      "comfort": 8.9,
      "tall": 9.2,
      "dog": 8.2,
      "sleep": 9.0,
      "warranty": 9.5,
      "service": 10.0,
      "sixyear": 9.6,
      "design": 8.7,
      "value": 9.2
    }
  },
  "ioniq": {
    "name": "Hyundai IONIQ 5 AWD Premium Business",
    "short": "IONIQ 5",
    "price": 55399.0,
    "strength": "Rymlig kupé, Relaxation-stol, skjutbart baksäte, 800 V och mycket bra resekomfort.",
    "scores": {
      "tech": 8.6,
      "software": 8.4,
      "charging": 9.5,
      "comfort": 9.7,
      "tall": 9.8,
      "dog": 10.0,
      "sleep": 9.8,
      "warranty": 8.8,
      "service": 8.4,
      "sixyear": 9.5,
      "design": 9.0,
      "value": 9.3
    }
  },
  "g6": {
    "name": "XPENG G6 AWD Performance",
    "short": "G6",
    "price": 55390.0,
    "strength": "451 kW DC, 5C-LFP, massiv tekniknivå, massage/ventilation och 7 års garanti.",
    "scores": {
      "tech": 10.0,
      "software": 10.0,
      "charging": 10.0,
      "comfort": 9.1,
      "tall": 8.8,
      "dog": 8.8,
      "sleep": 8.5,
      "warranty": 10.0,
      "service": 5.5,
      "sixyear": 8.8,
      "design": 9.8,
      "value": 9.5
    }
  }
};
