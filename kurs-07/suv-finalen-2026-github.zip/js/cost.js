
(function(){
const cars=window.CARS;
const cfg={ev6:{cons:21.0,service:360,tires:650,residual:40,rate:1.99,fee:290,monthlyFee:15},ioniq:{cons:20.5,service:360,tires:650,residual:40,rate:1.99,fee:495,monthlyFee:15},g6:{cons:21.5,service:450,tires:800,residual:36,rate:0.99,fee:349,monthlyFee:15}};
["km","electricity","down","years"].forEach(id=>document.getElementById(id)?.addEventListener("input",render));
["ev6","ioniq","g6"].forEach(id=>["price","residual","rate","cons","service","tires"].forEach(f=>document.getElementById(`${id}-${f}`)?.addEventListener("input",render)));
function annuity(principal,annualRate,n){const r=annualRate/100/12;if(r===0)return principal/n;return principal*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);}
function euro(n){return new Intl.NumberFormat("sv-FI",{style:"currency",currency:"EUR",maximumFractionDigits:0}).format(n)}
function render(){
 const km=+document.getElementById("km").value||0,electricity=+document.getElementById("electricity").value||0,down=+document.getElementById("down").value||0,years=+document.getElementById("years").value||6,months=years*12;
 const cards=[];
 ["ev6","ioniq","g6"].forEach(id=>{
  const p=+document.getElementById(`${id}-price`).value,residualPct=+document.getElementById(`${id}-residual`).value,rate=+document.getElementById(`${id}-rate`).value,cons=+document.getElementById(`${id}-cons`).value,serviceY=+document.getElementById(`${id}-service`).value,tiresY=+document.getElementById(`${id}-tires`).value;
  const principal=p*(1-down/100)+cfg[id].fee,financeMonths=Math.min(72,months),payment=annuity(principal,rate,financeMonths);
  const financeInterest=Math.max(0,payment*financeMonths-principal)+(cfg[id].monthlyFee*financeMonths)+cfg[id].fee;
  const depreciation=(p-(p*residualPct/100))/months,interest=financeInterest/months,energy=((km/12)/100*cons*electricity),service=serviceY/12,tires=tiresY/12,total=depreciation+interest+energy+service+tires;
  cards.push({id,total,depreciation,interest,energy,service,tires,residual:p*residualPct/100});
 });
 cards.sort((a,b)=>a.total-b.total);
 document.getElementById("costResults").innerHTML=cards.map((x,i)=>`<article class="money-card"><div class="badge ${i===0?"good":""}">${i===0?"Lägst scenario":"Scenario"}</div><h3>${cars[x.id].name}</h3><div class="money-total">${euro(x.total)}<small style="font-size:.9rem;color:#73808a"> / mån</small></div><div class="cost-lines"><div class="cost-line"><span>Värdeminskning</span><strong>${euro(x.depreciation)}</strong></div><div class="cost-line"><span>Ränta & finans.avgifter</span><strong>${euro(x.interest)}</strong></div><div class="cost-line"><span>El</span><strong>${euro(x.energy)}</strong></div><div class="cost-line"><span>Servicebudget</span><strong>${euro(x.service)}</strong></div><div class="cost-line"><span>Däckbudget</span><strong>${euro(x.tires)}</strong></div><div class="cost-line"><span>Antaget restvärde</span><strong>${euro(x.residual)}</strong></div></div></article>`).join("");
}
window.resetCosts=function(){document.getElementById("km").value=15000;document.getElementById("electricity").value=0.18;document.getElementById("down").value=20;document.getElementById("years").value=6;["ev6","ioniq","g6"].forEach(id=>{for(const f of ["residual","rate","cons","service","tires"])document.getElementById(`${id}-${f}`).value=cfg[id][f];document.getElementById(`${id}-price`).value=cars[id].price;});render();}
render();
})();
