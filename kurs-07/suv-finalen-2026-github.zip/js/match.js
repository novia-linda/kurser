
(function(){
const cars=window.CARS;
const criteria={
tech:["Teknik & gadgets","Hur mycket bilen känns som en dator på hjul."],
software:["Mjukvara & OTA","Gränssnitt, appar, uppdateringar och digitala funktioner."],
charging:["Snabbladdning","Arkitektur och laddtid på långresa."],
comfort:["Körkomfort","Fjädring, ljudnivå och avslappnad långfärd."],
tall:["Förarstol 195 cm","Justermån, lårstöd, insteg och långfärdskomfort."],
dog:["Golden & bagage","Bagagets form, höjd och vardagspraktik."],
sleep:["Sova i bilen","Fällt golv, kupéform och campingmöjlighet."],
warranty:["Garanti","Vanlig bilgaranti + batteriskydd."],
service:["Service nära Vasa","Hur enkelt det är att få märkesstöd lokalt idag."],
sixyear:["6-årstrygghet","Mognad, nätverk och rimlig äganderisk över sex år."],
design:["Design i silver","Hur väl bilen matchar mjuka former + metallic silver."],
value:["Pris/kvalitet","Helheten i relation till inköpspris."]
};
const defaults={tech:12,software:9,charging:10,comfort:12,tall:12,dog:9,sleep:5,warranty:8,service:7,sixyear:6,design:6,value:8};
const presets={
"var-mix":defaults,
"teknik":{tech:18,software:16,charging:16,comfort:10,tall:8,dog:5,sleep:3,warranty:6,service:4,sixyear:3,design:6,value:5},
"komfort":{tech:5,software:3,charging:7,comfort:18,tall:18,dog:15,sleep:10,warranty:7,service:6,sixyear:5,design:3,value:3},
"trygg":{tech:5,software:3,charging:7,comfort:10,tall:10,dog:6,sleep:3,warranty:15,service:16,sixyear:15,design:3,value:7},
"langresa":{tech:7,software:5,charging:18,comfort:17,tall:15,dog:8,sleep:5,warranty:6,service:4,sixyear:5,design:3,value:7}
};
const holder=document.getElementById("weightControls");if(!holder)return;
holder.innerHTML=Object.entries(criteria).map(([key,[label,help]])=>`<div class="range-control"><label for="w-${key}"><span>${label}</span><span id="v-${key}">${defaults[key]}</span></label><input id="w-${key}" data-key="${key}" type="range" min="0" max="20" step="1" value="${defaults[key]}"><small>${help}</small></div>`).join("");
function setPreset(name){Object.entries(presets[name]).forEach(([k,v])=>{document.getElementById("w-"+k).value=v;document.getElementById("v-"+k).textContent=v;});render();}
document.querySelectorAll("[data-preset]").forEach(b=>b.addEventListener("click",()=>setPreset(b.dataset.preset)));
holder.addEventListener("input",e=>{if(e.target.matches("input[type=range]")){document.getElementById("v-"+e.target.dataset.key).textContent=e.target.value;render();}});
function render(){
 const weights={};let sumW=0;
 Object.keys(criteria).forEach(k=>{weights[k]=+document.getElementById("w-"+k).value;sumW+=weights[k];});
 const result=Object.entries(cars).map(([id,c])=>{let s=0;Object.keys(criteria).forEach(k=>s+=(c.scores[k]||0)*weights[k]);return{id,c,score:sumW?s/sumW:0};}).sort((a,b)=>b.score-a.score);
 document.getElementById("rankings").innerHTML=result.map((r,i)=>`<article class="rank-card ${i===0?"winner":""}"><div class="rank">${i===0?"Vinnare med dina vikter":"Plats "+(i+1)}</div><h3>${r.c.name}</h3><div class="total-score">${r.score.toFixed(2)}<small style="font-size:.9rem;color:#74808a"> / 10</small></div><div class="reason">${r.c.strength}</div></article>`).join("");
 const rows=Object.entries(criteria).map(([k,[label]])=>`<tr><td><strong>${label}</strong></td>${result.map(r=>`<td>${r.c.scores[k].toFixed(1)}</td>`).join("")}</tr>`).join("");
 document.getElementById("scoreTable").innerHTML=`<thead><tr><th>Kriterium</th>${result.map(r=>`<th>${r.c.short}</th>`).join("")}</tr></thead><tbody>${rows}</tbody>`;
}
render();
})();
